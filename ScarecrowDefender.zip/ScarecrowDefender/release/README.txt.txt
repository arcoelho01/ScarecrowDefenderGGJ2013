It's an Unity WebPlayer game, just open the file link ScarecrowDefender in your browser.
The player plugin is available at: www.unity3d.com