using UnityEngine;
using System.Collections;
[System.Serializable]
public class Sprite {
	public Texture2D image;
	public float time;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
