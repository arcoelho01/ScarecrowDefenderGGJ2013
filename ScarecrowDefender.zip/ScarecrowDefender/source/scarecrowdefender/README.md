espantalho_de_ferro
===================